# CyberCoach AI — Android App v1

ده مشروع Android Native فعلي كبداية للتطبيق.

## الموجود
- Home dashboard
- Placement Test
- 12 مسار
- 100 Module مخطط لها
- 3 فيديوهات لكل Module:
  1. شرح من الصفر
  2. شرح بطريقة مختلفة
  3. تطبيق عملي آمن
- Mini Quiz
- Adaptive recommendation concept
- XP / Levels / Daily missions
- Glossary عربي/إنجليزي
- AI Coach UI
- واجهة مناسبة للموبايل

## التشغيل
افتح المجلد في Android Studio ثم اعمل Sync وRun.

ملاحظة: بيئة المحادثة الحالية لا تحتوي Android SDK/Gradle build tools، لذلك تم تسليم Source Project جاهز للبناء في Android Studio بدل ادعاء وجود APK تم اختباره.
