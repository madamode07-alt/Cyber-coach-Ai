package com.cybercoach.ai

import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val bg = Color.rgb(16,19,26)
    private val card = Color.rgb(28,33,43)
    private val accent = Color.rgb(108,99,255)
    private val green = Color.rgb(0,194,168)

    private val paths = listOf(
        "🛡️ أساسيات الأمن السيبراني" to 6,
        "🌐 الشبكات" to 8,
        "🐧 لينكس" to 7,
        "🐍 بايثون للأمن السيبراني" to 7,
        "🌍 أمن تطبيقات الويب" to 10,
        "🔵 Blue Team — الدفاع" to 9,
        "🚨 SOC Analyst" to 9,
        "🔎 التحقيق الجنائي الرقمي" to 8,
        "🧯 الاستجابة للحوادث" to 8,
        "☁️ أمن الحوسبة السحابية" to 8,
        "🚩 CTF & Security Labs" to 10,
        "🧠 الأمن المتقدم" to 10
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(28, 24, 28, 20)
        }
    }

    private fun text(t: String, size: Float, bold: Boolean=false): TextView =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(Color.WHITE)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 8, 0, 8)
        }

    private fun button(t: String, action: () -> Unit): Button =
        Button(this).apply {
            text = t
            setTextColor(Color.WHITE)
            setBackgroundColor(accent)
            setOnClickListener { action() }
            isAllCaps = false
            val p = LinearLayout.LayoutParams(-1, 58)
            p.setMargins(0, 8, 0, 8)
            layoutParams = p
        }

    private fun showHome() {
        val root = base()
        root.addView(text("CYBERCOACH AI", 28f, true))
        root.addView(text("من الصفر لحد مستوى متقدم — بالعربي والإنجليزي", 16f))
        root.addView(text("🔥 Level 1 • 0 XP\n🎯 الهدف الحالي: Cyber Foundations", 15f))
        root.addView(button("🚀 اختبار تحديد المستوى") { placementTest() })
        root.addView(button("📚 المسارات التعليمية") { pathsScreen() })
        root.addView(button("🏆 الإنجازات والـ XP") { achievements() })
        root.addView(button("📖 القاموس التقني") { glossary() })
        root.addView(button("🤖 AI Coach") { aiCoach() })
        setContentView(root)
    }

    private fun pathsScreen() {
        val root = base()
        root.addView(text("المسارات", 26f, true))
        root.addView(text("اختار مسار وابدأ التعلم. كل Module فيه 3 طرق شرح.", 15f))
        paths.forEachIndexed { i, pair ->
            root.addView(button("${i+1}. ${pair.first}\n${pair.second} Modules • فيديو 1 + 2 + 3") {
                moduleScreen(i, pair.first, pair.second)
            })
        }
        root.addView(button("⬅ رجوع") { showHome() })
        setContentView(root)
    }

    private fun moduleScreen(index: Int, path: String, count: Int) {
        val root = base()
        root.addView(text(path, 23f, true))
        root.addView(text("Module 1 من $count", 15f))
        root.addView(text("الموضوع: شرح المفهوم بطريقة مبسطة", 18f, true))

        root.addView(button("▶ فيديو 1 — شرح من الصفر") {
            Toast.makeText(this, "Video 1: شرح من الصفر", Toast.LENGTH_SHORT).show()
        })
        root.addView(button("▶ فيديو 2 — شرح بطريقة مختلفة") {
            Toast.makeText(this, "Video 2: طريقة شرح بديلة", Toast.LENGTH_SHORT).show()
        })
        root.addView(button("▶ فيديو 3 — تطبيق عملي آمن") {
            Toast.makeText(this, "Video 3: Safe Lab", Toast.LENGTH_SHORT).show()
        })

        root.addView(button("📝 Mini Quiz") { quiz() })
        root.addView(button("🤖 مش فاهم؟ خلّي AI يشرح بطريقة تانية") { aiCoach() })
        root.addView(button("⬅ رجوع للمسارات") { pathsScreen() })
        setContentView(root)
    }

    private fun quiz() {
        val root = base()
        root.addView(text("Mini Quiz", 26f, true))
        root.addView(text("مثال: DNS اختصار لإيه؟", 19f, true))
        val group = RadioGroup(this)
        listOf(
            "Domain Name System",
            "Digital Network Security",
            "Data Node Service",
            "Domain Network Server"
        ).forEach { answer ->
            val r = RadioButton(this)
            r.text = answer
            r.textSize = 16f
            r.setTextColor(Color.WHITE)
            group.addView(r)
        }
        root.addView(group)
        root.addView(button("تحقق من الإجابة") {
            val selected = group.checkedRadioButtonId
            if (selected == -1) {
                Toast.makeText(this, "اختار إجابة الأول", Toast.LENGTH_SHORT).show()
            } else {
                val r = findViewById<RadioButton>(selected)
                if (r.text == "Domain Name System") {
                    Toast.makeText(this, "✅ صح! +100 XP", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "❌ راجع Video 2 أو Video 3", Toast.LENGTH_LONG).show()
                }
            }
        })
        root.addView(button("⬅ رجوع") { showHome() })
        setContentView(root)
    }

    private fun placementTest() {
        val root = base()
        root.addView(text("اختبار تحديد المستوى", 25f, true))
        root.addView(text("الاختبار الحقيقي هيحدد نقطة البداية والمسارات اللي تحتاجها.", 15f))
        root.addView(text("السؤال 1/10: أي بروتوكول يستخدم غالبًا لنقل صفحات الويب الآمنة؟", 18f, true))
        val group = RadioGroup(this)
        listOf("HTTPS", "FTP", "SMTP", "DHCP").forEach {
            val r=RadioButton(this); r.text=it; r.textSize=16f; r.setTextColor(Color.WHITE); group.addView(r)
        }
        root.addView(group)
        root.addView(button("التالي") {
            Toast.makeText(this, "تم تسجيل الإجابة — الاختبار الكامل في محرك التقييم.", Toast.LENGTH_SHORT).show()
        })
        root.addView(button("⬅ رجوع") { showHome() })
        setContentView(root)
    }

    private fun achievements() {
        val root=base()
        root.addView(text("🏆 الإنجازات",26f,true))
        root.addView(text("XP: 0\nLevel: Beginner\n🔥 Streak: 0 يوم",18f))
        root.addView(text("المهام اليومية",20f,true))
        root.addView(text("• تعلم 10 دقائق → +100 XP\n• حل 5 أسئلة → +100 XP\n• تعلم 3 مصطلحات → +75 XP",16f))
        root.addView(button("⬅ رجوع"){showHome()})
        setContentView(root)
    }

    private fun glossary() {
        val root=base()
        root.addView(text("📖 القاموس التقني",26f,true))
        val terms=listOf(
            "DNS — Domain Name System — نظام أسماء النطاقات",
            "IP — Internet Protocol — بروتوكول الإنترنت",
            "TCP — Transmission Control Protocol — بروتوكول التحكم في الإرسال",
            "HTTPS — Hypertext Transfer Protocol Secure — بروتوكول نقل النص التشعبي الآمن",
            "MFA — Multi-Factor Authentication — المصادقة متعددة العوامل",
            "SIEM — Security Information and Event Management — إدارة معلومات وأحداث الأمن",
            "SOC — Security Operations Center — مركز العمليات الأمنية",
            "XSS — Cross-Site Scripting — البرمجة النصية عبر المواقع",
            "CTF — Capture The Flag — التقاط العلم"
        )
        terms.forEach { root.addView(text(it,15f)) }
        root.addView(button("⬅ رجوع"){showHome()})
        setContentView(root)
    }

    private fun aiCoach() {
        val root=base()
        root.addView(text("🤖 CyberCoach AI",26f,true))
        root.addView(text("اكتب المصطلح أو الموضوع اللي مش فاهمه. النسخة الكاملة هتشرحلك بالمصري أو العربي أو الإنجليزي، وتقدر تطلب شرح أبسط أو مثال آمن.",15f))
        val input=EditText(this)
        input.hint="مثال: يعني إيه DNS؟"
        input.setTextColor(Color.WHITE)
        input.setHintTextColor(Color.LTGRAY)
        root.addView(input)
        root.addView(button("اشرحلي") {
            val q=input.text.toString().trim()
            val ans=if(q.isEmpty()) "اكتب موضوع الأول." else
                "مثال مبسط: DNS هو النظام اللي بيحوّل اسم الموقع زي example.com لعنوان IP. لو لسه مش واضح، جرّب فيديو 2 ثم فيديو 3."
            root.addView(text(ans,16f,true))
        })
        root.addView(button("⬅ رجوع"){showHome()})
        setContentView(root)
    }
}
