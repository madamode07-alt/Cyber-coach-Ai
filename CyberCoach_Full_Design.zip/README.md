# CyberCoach AI
ارفع الملفات كلها إلى جذر المستودع.
الإصلاح الأساسي موجود في gradle.properties:
android.useAndroidX=true
android.enableJetifier=true
بعد الرفع افتح Actions ثم Build CyberCoach APK ثم Run workflow.
بعد نجاح البناء حمّل Artifact باسم CyberCoach-debug-apk.
