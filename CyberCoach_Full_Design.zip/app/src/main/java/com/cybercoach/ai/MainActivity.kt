package com.cybercoach.ai
import android.os.Bundle
import android.graphics.Color
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val bg=Color.rgb(16,19,27); private val card=Color.rgb(27,34,48)
    override fun onCreate(b:Bundle?){super.onCreate(b);home()}
    private fun t(s:String,n:Float)=TextView(this).apply{text=s;textSize=n;setTextColor(Color.WHITE);setPadding(20,20,20,20)}
    private fun home(){
        val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg);setPadding(20,20,20,20)}
        l.addView(t("CYBERCOACH AI",28f));l.addView(t("اتعلم الأمن السيبراني من الصفر للاحتراف",19f))
        l.addView(t("كل مسار فيه 3 طرق شرح: أساسي، بديل، وعملي.",16f))
        arrayOf("أساسيات الأمن السيبراني","الشبكات","لينكس","بايثون للأمن السيبراني","أمن تطبيقات الويب","الدفاع السيبراني","SOC Analyst","التحقيق الجنائي الرقمي","أمن السحابة","CTF ومعامل آمنة").forEach{p->
            l.addView(Button(this).apply{text="🛡 $p";setOnClickListener{path(p)}})}
        setContentView(ScrollView(this).apply{addView(l)})
    }
    private fun path(p:String){
        val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg);setPadding(20,20,20,20)}
        l.addView(t(p,25f));l.addView(t("اختار طريقة الشرح:",18f))
        arrayOf("الفيديو 1: شرح مبسط من الصفر","الفيديو 2: شرح بطريقة مختلفة","الفيديو 3: شرح عملي وتطبيق آمن").forEachIndexed{i,v->
            l.addView(Button(this).apply{text=v;setOnClickListener{Toast.makeText(this@MainActivity,if(i==0)"ابدأ بالشرح الأساسي" else if(i==1)"جرب التشبيه والشرح البديل" else "تطبيق داخل بيئة تعليمية مصرح بها فقط",Toast.LENGTH_LONG).show()}})
        }
        l.addView(Button(this).apply{text="رجوع";setOnClickListener{home()}})
        setContentView(l)
    }
}
